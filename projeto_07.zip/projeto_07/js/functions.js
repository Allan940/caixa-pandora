$(function(){


MenuMobile();
function MenuMobile(){


$('.mobile').click(function(e){
	e.stopPropagation();
	$('.mobile ul').slideToggle();

})

   $('body').click(function(){
	$('.mobile ul').fadeOut();
	
})

}

}) 