$(function(){


 $('.mosaico .container .mosaico-wraper').slick({
 	infinite:true,
    centerMode:false,
    slidesToShow:6,
    arrows: false,
    responsive:[

       {
       	breakpoint:768,
		     settings:{
			      	centerMode:false,
			      	slidesToShow:3,
			      	arrows:false,
			      	autoplay:true,
			      	autoplaySpeed:3000,
			     
		      }
       },
       {

        breakpoint:500,
        settings:{
        	centerMode:true,
        	slidesToShow:1,
        	arrows:false,
        	slidesToScroll: 1,
        	autoplay: true,
        	autoplaySpeed: 2000,
        }

       }
    ]

 });



})