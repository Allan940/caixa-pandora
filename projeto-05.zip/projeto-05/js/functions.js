$(function(){


abrirMenuMobile();
MenuScroll();
//Descer o scroll de acordo com o menu
function MenuScroll(){
	$('nav a').click(function(){

   var href = $(this).attr('href');
	var offSet = $(href).offset().top;

		$('html,body').animate({
			scrollTop:offSet
		},1000)
	 
	})


}
//menu para as versoes mde dispositivos mobile
function abrirMenuMobile(){
	$('.menu-mobile').click(function(e){
		e.stopPropagation();
		$('.menu-mobile ul').slideToggle();
	})
}

FecharMenuMobile();

function FecharMenuMobile(){
	$('body').click(function(){
	 $('.menu-mobile ul').fadeOut();
	})
}


}) 