$(function(){


  var curIndex = 0;
  var amt;	
   

  initSlider()

  function initSlider(){
  	amt = $('.sobre-autor').length;
  	var totalWidth = 100 * amt;
  	var singleWidth = 100 / amt
    $('.sobre-autor').css('width',singleWidth+'%')
    $('.scrollWraper').css('width',totalWidth+'%')

    for(var i = 0; i < amt; i++){
  	   if(i == 0){
  		$('.slider-bullets').append('<span style="background-color:rgb(170,170,170);"></span>')
     	}else{
  		   $('.slider-bullets').append('<span></span>')
  	    } 
  }


  }


  autoPlay();
  function autoPlay(){
    setInterval(function(){
    	curIndex++
    	if(curIndex == amt){
    		curIndex = 0
    	}
       goToSlider(curIndex)

    },3000)
  }


function goToSlider(){
	var offSet = $('.sobre-autor').eq(curIndex).offset().left - $('.scrollWraper').offset().left;
	$('.slider-bullets span').css('background-color','#ccc');
	$('.slider-bullets span').eq(curIndex).css('background-color','rgb(170,170,170')

	$('.scrollEquipe').animate({
		'scrollLeft':offSet+'px'
	})
}



})