$(function(){


$('#form1').submit(function(e){
	e.preventDefault();

	var nome = $('input[name=nome]').val();
	var email = $('input[name=email]').val();


//VERIFICANDO SE OS CAMPOS ESTÃO VALIDOS PARA O ENVIO
	if(ValidarNome() ==  false){
      campoInvalido($('input[name=nome]'))
	}else if(validarEmail() == false){
       campoInvalido($('input[name=email]'))
	}else{
		alert('Formulario enviado com sucesso!!!')
	}


//FUNÇÕES DE ESTILIZACAO DOS CAMPOS

  function campoInvalido(el){
  	 el.css('border','3px solid red');
      el.val('CAMPO INVÁLIDO');
  }

  resetarCampo();
  function resetarCampo(){
    $('input[type=text]').focus(function(){
    $(this).css('border','1px solid #ccc')
    $(this).val('')
    })
  }


//FUNÇÕES DE VERIFICACAO DOS CAMPOS

ValidarNome();
function ValidarNome(){
	 var amount = nome.split(' ').length;
	 var splitstr = nome.split(' ');
  
      if(amount >= 2){
          for(var i = 0; i < amount; i++){
              if(splitstr[i].match(/^[A-Z]{1}[a-z]{1,}$/)){
                   
              }else{
               return false            
              }
          }

      }else{
            
          return false
      }
  }


validarEmail();
function validarEmail(){
if(email.match(/^([a-z0-9-_.]{1,})+@+([a-z.]{1,})$/)){

}else{
	return false
}

}

	
})

})