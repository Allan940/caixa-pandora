$(function(){


  MenuScroll();
  function MenuScroll(){
  	$('nav a').click(function(){

   var href = $(this).attr('href');
   var Offset = $(href).offset().top

  		$('html,body').animate({
  			scrollTop: Offset
  		},1000)
  	})
  }


})