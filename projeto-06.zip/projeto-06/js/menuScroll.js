$(function(){


        var directory = 'file:///C:/xampp/htdocs/curso%20WebMaster/Projetos/projeto-06/'
       
        $('#goContato').click(function(){
        	 return false
            location.href = directory+'index.html?contato';
           
        })
        

        checkUrl();


        function checkUrl(){
            var directory = 'file:///C:/xampp/htdocs/curso%20WebMaster/Projetos/projeto-06/'
            var url = location.href.split('/');
            var curPage = url[url.length-1].split('?');
       
            if(curPage[1] == 'contato'){
              $('header nav a').css('color','black');
              $('footer nav a').css('color','white');
              $('#goContato').css('color','#EB2D2D');
              $('html,body').animate({'scrollTop':$('#contato').offset().top});
            }else{
            	al
            }

        }

})